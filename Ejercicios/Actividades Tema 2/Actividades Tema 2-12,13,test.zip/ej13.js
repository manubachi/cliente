var valores = [false, 3, "php", true, "javascript", 1];
var cadenas = [];
var numeros = [];
var booleanos = [];

for(i=0;valores.length;i++){
  if(typeof valores)
}

for(i=0;cadenas.length;i++){
  alert(cadenas[i]);
}
