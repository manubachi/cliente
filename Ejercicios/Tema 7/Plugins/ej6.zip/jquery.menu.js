(function($){
	$.fn.extend({
		menu: function(opciones){
			return this.each(function() {
				var ops = $.extend({}, $.fn.menu.defaults,opciones);
				$('a').css({
    		 		"color":ops.color2,
             		"text-decoration": "none",
             		"text-align": "center"
    			});

    			$('nav > div').css({
					"color" : ops.color2,
					"background-color":ops.color1,
    				"float": "left",
            		"text-align":"center",
            		"margin-left": "20px",
            		"margin-right": "20px"
    			});


    			$("nav > div:eq(1)").mouseenter(function(e){
    				$("nav > div:eq(1) > div:eq(1)").show(ops.velocidad);
    			});

    			$("nav > div:eq(2)").mouseenter(function(e){
    				$("nav > div:eq(2) > div:eq(1)").show(ops.velocidad)
    			});

    			$("nav > div:eq(1)").mouseleave(function(e){
    				$("nav > div:eq(1) > div:eq(1)").hide(ops.velocidad)
    			});

    			$("nav > div:eq(2)").mouseleave(function(e){
    				$("nav > div:eq(2) > div:eq(1)").hide(ops.velocidad)
    			});


    			/*elem.mouseleave(function(e){
    				elem.children().hide(200)
    			});*/
    			/*$(this).click(function(){
    				alert(mensaje);
    			});*/
			});
		}
	});
	$.fn.menu.defaults = {
		color1: "blue",
	   	color2: "white",
	   	velocidad: 200,
   };
})(jQuery)
    /*$.fn.extend = function(){
    	var ops = $.extend({}, $.fn.menu.defaults,opciones);
    	$('a').css({
    		 color:black,
             text-decoration: none,
             text-align: center
    	});

    	$('nav > div').css({
    		float: left,
            text-align: center,
            margin-left: 20px,
            margin-right: 20px
    	});/*
    	this.each(function() {
    		elem = $(this)
    		elem.mouseenter(function(e){
    			elem.children().show(200)
    		});

    		elem.mouseleve(function(e){
    			elem.children().hide(200)
    		});
    	});*/

    //};
/*
     $.fn.menu.defaults = {
        color: {color: "black"},
        dec: {text-decoration: "none"},
        alineacion: {text-align: "center"},
        fl: {float: "left"},
        margin-left: 20px,
        margin-right: 20px,
     };*/
//})(jQuery);
